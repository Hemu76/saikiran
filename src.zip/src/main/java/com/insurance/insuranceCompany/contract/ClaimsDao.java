package com.insurance.insuranceCompany.contract;

import java.util.ArrayList;
import java.util.List;

import com.insurance.insuranceCompany.model.CB;
import com.insurance.insuranceCompany.model.Claim;
import com.insurance.insuranceCompany.model.ClaimApplication;
import com.insurance.insuranceCompany.model.ClaimBills;
import com.insurance.insuranceCompany.model.ClaimHistory;
import com.insurance.insuranceCompany.model.CoveredDiseases;
import com.insurance.insuranceCompany.model.ReUpload;
import com.insurance.insuranceCompany.model.Uploads;

public interface ClaimsDao {

	ArrayList<Claim> getAllClaims();

	ArrayList<Claim> getFilteredClaims(String status);

	Claim getClaimById(int clamId);

	ArrayList<Claim> viewAllClaims();

	Claim viewClaimById(int clamId);

	int editClaimById(int clamId, String clamRemarks, String clamStatus);

	void addClaim(ClaimBills claim);

	void setClaim(int i, double requestAmount, String hospname);

	Claim getClaimByid(int clamIplcId);

	void setDocs(String f, String filePath, int cid, int amt);

	ArrayList<ClaimBills> getDocs(int clamId);

	ClaimBills getDocBills(int billIndex);

	void addClaimApplication(ClaimApplication application);

	List<ClaimApplication> getAllApplications();

	Claim getClaimByPolicy(int id);

	void updateClaimBill(CB bill, int cid);

	List<CoveredDiseases> getAllCoveredDiseases(int id);

	void updateClaimBill(int clamId, String clamRemarks, String clamStatus, String clamProcessedAmount);

	void updateDate(int clamId);

	ClaimBills updt(int billIndex);

	List<ClaimHistory> getHistory(int cid);

	void addRequiredUploads(ReUpload upload);

	List<ReUpload> getAllReUploads();

	void addUploads(Uploads up);

	List<Uploads> getFlow(int id);

}